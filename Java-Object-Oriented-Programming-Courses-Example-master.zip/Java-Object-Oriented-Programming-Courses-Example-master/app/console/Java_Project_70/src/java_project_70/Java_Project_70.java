/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_70;
import java.util.Scanner;
/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_70 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner tara = new Scanner(System.in);
        sınıflar d1 = new sınıflar(7, 8);
        System.out.println(d1.enial());
        d1.endegistir(4);
        System.out.println(d1.enial());
    }
    
}
