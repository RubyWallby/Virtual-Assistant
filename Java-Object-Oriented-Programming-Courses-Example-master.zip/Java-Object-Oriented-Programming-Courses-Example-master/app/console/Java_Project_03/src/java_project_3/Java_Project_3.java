/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_3;

/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //
        // Ders Notları :::
        //
        // Tam sayılar ::
        //
        // Byte : 8 Bit
        // Short : 16 Bit
        // Integer : 32 Bit
        // Long : 64 Bit
        // Ondalık sayılar ::
        //
        // Float : 32 Bit
        // Double : 64 Bit
        //
        // Boolean Sayılar ::
        //
        // Boolean : 1 Bit
        //
        // Karakterler ::
        //
        // Char : 16 Bit
        // String : Değişebilir bit değeri.
        //
        // Değişkenler ::
        //
        // Verileri saklamak, kullanmak ve veriler üzerinde değişiklik yapmak
        // için kullanılır. Tanımlanan anahtar isimlerdir.
        // Değişken tanımlarken türkçe karakterler kullanılmaz, özel karakter ve
        // boşluk kullanılmaz.
        //
        // Örnekler :::
        //
        int number_1 = 6;
        System.out.println(number_1);
        //
        int number_2;
        number_2 = 4;
        System.out.println(number_2);
        //
        int a, b = 6;
        a = 4;
        System.out.println(a);
        //
        int a1, b2 = 6;
        a1 = 4;
        System.out.println("B'nin değeri : " + b2);
        //
        int a3, b4 = 6;
        char text_1 = 78;
        System.out.println("Unicode karşılığı : " + text_1);
        //
        int a5, b6 = 6;
        char text_2 = 78;
        float pi = 3.14f;
        System.out.println("Pi sayısı : " + pi);
        //
        // Float değişken tanımlamak için sayının yanına "f" karakterini eklemeliyiz.
        //
    }
    
}
