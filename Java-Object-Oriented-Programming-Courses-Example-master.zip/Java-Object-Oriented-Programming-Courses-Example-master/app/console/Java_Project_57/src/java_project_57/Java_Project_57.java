/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_57;

/**
 *
 * @author root
 */
public class Java_Project_57 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       birlestir("Metin1","Metin2");
       String metin1 = "Hello";
       String metin2 = "World!";
       birlestir(metin1, metin2);
    }
    public static void birlestir(String metin1, String metin2){
        System.out.println(metin1 + " " + metin2);
    }
    
}
