/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_71;

/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_71 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        dortgen d1 = new dortgen(7, 5); 
    }
    
}
