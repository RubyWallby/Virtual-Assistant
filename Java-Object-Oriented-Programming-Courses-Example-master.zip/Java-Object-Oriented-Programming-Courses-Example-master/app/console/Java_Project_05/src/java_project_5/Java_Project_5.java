/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_5;
import java.util.Scanner;
/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //
        // Ders Notları :::
        //
        // Kullanıcıdan veri alma işlemleri
        //
        System.out.println("Adınızı giriniz : ");
        Scanner tara = new Scanner(System.in);
        String ad = tara.nextLine();
    }
    
}
