/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_67;

/**
 *
 * @author ismailtasdelen
 */
public class school_class {
    public String adsoyad;
    public String sinif;
    public String tc;
    public String dersadi;
    public int dersnotu;
    public void kontol()
    {
    if (dersnotu < 40)
    {
        System.out.println("Kaldı.");
    }
    else
    {
        System.out.println("Geçti.");
    }
    }
    
}
