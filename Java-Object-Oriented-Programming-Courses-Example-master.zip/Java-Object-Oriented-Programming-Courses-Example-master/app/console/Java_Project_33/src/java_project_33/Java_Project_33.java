/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_33;

/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_33 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
    for (int i=1; i < 7; i++)
    {
    System.out.println("Yere çöp atmayacağım.");
    }
    }
    
}
