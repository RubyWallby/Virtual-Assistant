/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_56;

/**
 *
 * @author root
 */
public class Java_Project_56 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        topla(3, 4);
    }
    public static void topla(int x, int y){
    int topla = x + y;
    System.out.println(topla);
    }
    
}
