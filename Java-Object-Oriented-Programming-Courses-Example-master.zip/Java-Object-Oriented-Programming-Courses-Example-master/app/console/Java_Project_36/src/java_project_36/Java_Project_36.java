/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_36;

/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_36 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double carpim = 1;
        for (double i = 1; i <= 100; i++)
        {
            carpim = carpim * i;
        }
        System.out.println(carpim);
    }
    
}
