/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_24;

/**
 *
 * @author ismailtasdelen
 */
public class Java_Project_24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //
        // Örnek :
        //
        String s1 = "123";
        int x1 = Integer.valueOf(s1);
        System.out.println(x1-2);
        //
        // Örnek :
        //
        String s2 = "123";
        int x2 = Integer.parseInt(s1);
        System.out.println(x2-2);
    }
    
}
