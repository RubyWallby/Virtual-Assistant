/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_project_8;
/**
 *
 * @author Ismail Tasdelen
 */
public class Java_Project_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //
        // Örnek :
        //
        // Tanımlanan iki değerin toplamını, farkını, çarpımını, bölümünü,
        //  kalanını ekrana yazdıran programı yazınız.
        //
        int a = 10;
        int b = 2;
        System.out.println("Toplam : " + (a+b));
        System.out.println("Fark : " + (a-b));
        System.out.println("Çarpım : "+ (a*b));
        System.out.println("Bölümü : "+ (a/b));
        System.out.println("Kalanı : "+ (a%b));
    }
    
}
